package com.macromaster.integration;

import com.macromaster.gui.MacroListScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Optional Mod Menu integration. The "modmenu" entrypoint is only instantiated
 * when Mod Menu is installed, so this class is never loaded otherwise.
 */
public class MacroMasterModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return MacroListScreen::new;
    }
}
