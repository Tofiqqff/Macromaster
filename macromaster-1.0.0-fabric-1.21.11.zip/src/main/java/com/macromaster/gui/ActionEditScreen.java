package com.macromaster.gui;

import com.macromaster.gui.widget.PushButton;
import com.macromaster.macro.MacroAction;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Configures a single action: key picker (for key actions) and
 * duration / delay fields with quick presets.
 */
public class ActionEditScreen extends Screen {
    private final Screen parent;
    private final MacroAction action;
    private final boolean isNew;
    private InputUtil.Key key;
    private final List<PushButton> buttons = new ArrayList<>();
    private String fieldText = "";
    private boolean fieldFocused = false;
    private int fieldX, fieldY, fieldW, fieldH;

    public ActionEditScreen(Screen parent, MacroAction action, boolean isNew) {
        super(Text.literal("Edit Action"));
        this.parent = parent;
        this.action = action;
        this.isNew = isNew;
        this.key = action.toKey();
        this.fieldText = action.type == MacroAction.Type.WAIT ? String.valueOf(action.delayMs)
                : String.valueOf(action.durationMs);
    }

    @Override
    protected void init() {
        buttons.clear();
        boolean isKeyAction = action.type == MacroAction.Type.KEY_PRESS
                || action.type == MacroAction.Type.KEY_HOLD || action.type == MacroAction.Type.KEY_RELEASE;
        boolean hasField = action.type == MacroAction.Type.WAIT || action.type == MacroAction.Type.KEY_HOLD;

        int pw = 320;
        int px = width / 2 - pw / 2;
        int py = height / 2 - 80;

        if (isKeyAction) {
            buttons.add(new PushButton(px + pw - 100, py + 40, 90, 20,
                    key.getLocalizedText().getString(), PushButton.PRIMARY,
                    () -> client.setScreen(new KeyCaptureScreen(this, k -> {
                        key = k;
                        action.setKey(k);
                        init();
                    }))));
        }
        if (hasField) {
            fieldX = px + 110;
            fieldY = py + 68;
            fieldW = 70;
            fieldH = 18;
            buttons.add(new PushButton(fieldX + fieldW + 8, fieldY - 1, 40, 20, "ms", PushButton.GHOST, () -> {}));
            int[] presets = action.type == MacroAction.Type.WAIT
                    ? new int[]{10, 25, 50, 100, 250, 500, 1000}
                    : new int[]{100, 250, 500, 1000};
            int pxr = fieldX + fieldW + 56;
            for (int v : presets) {
                if (pxr + 34 > px + pw) break;
                int val = v;
                buttons.add(new PushButton(pxr, fieldY - 1, 32, 20, String.valueOf(v), PushButton.GHOST, () -> {
                    fieldText = String.valueOf(val);
                    applyField();
                }));
                pxr += 36;
            }
        }

        buttons.add(new PushButton(px + pw / 2 - 130, py + 118, 120, 22, isNew ? "Add" : "Save", PushButton.PRIMARY, () -> {
            applyField();
            action.setKey(key);
            if (parent instanceof MacroEditorScreen editor) {
                if (isNew) {
                    editor.addAction(action);
                } else {
                    editor.markDirty();
                }
            }
            close();
        }));
        buttons.add(new PushButton(px + pw / 2 + 10, py + 118, 120, 22, "Cancel", PushButton.GHOST, this::close));
    }

    private void applyField() {
        try {
            int v = Integer.parseInt(fieldText.trim());
            v = Math.max(0, Math.min(60000, v));
            if (action.type == MacroAction.Type.WAIT) {
                action.delayMs = v;
            } else if (action.type == MacroAction.Type.KEY_HOLD) {
                action.durationMs = Math.max(10, v);
            }
        } catch (NumberFormatException ignored) {
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (parent != null) {
            parent.render(ctx, mouseX, mouseY, delta);
        }
        ctx.fill(0, 0, width, height, 0x90000000);

        int pw = 320, ph = 160;
        int px = width / 2 - pw / 2, py = height / 2 - ph / 2 - 10;
        UiStyle.panel(ctx, px, py, pw, ph);

        ctx.drawCenteredText(textRenderer, action.type.label().toUpperCase(), width / 2, py + 12, UiStyle.TEXT);
        ctx.drawCenteredText(textRenderer, action.type.description(), width / 2, py + 26, UiStyle.TEXT_DIM);

        boolean isKeyAction = action.type == MacroAction.Type.KEY_PRESS
                || action.type == MacroAction.Type.KEY_HOLD || action.type == MacroAction.Type.KEY_RELEASE;
        if (isKeyAction) {
            ctx.drawText(textRenderer, "Key:", px + 20, py + 46, UiStyle.TEXT_DIM, false);
            ctx.drawText(textRenderer, key.getLocalizedText().getString(), px + 110, py + 46, UiStyle.TEXT, false);
        }
        if (action.type == MacroAction.Type.WAIT || action.type == MacroAction.Type.KEY_HOLD) {
            ctx.drawText(textRenderer, action.type == MacroAction.Type.WAIT ? "Delay:" : "Duration:",
                    px + 20, py + 74, UiStyle.TEXT_DIM, false);
            // text field
            UiStyle.fillRounded(ctx, fieldX, fieldY, fieldW, fieldH, 2, 0xFF101318);
            UiStyle.outline(ctx, fieldX, fieldY, fieldW, fieldH, fieldFocused ? UiStyle.ACCENT : UiStyle.BORDER);
            ctx.drawText(textRenderer, fieldText + (fieldFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""),
                    fieldX + 5, fieldY + 5, UiStyle.TEXT, false);
        }

        for (PushButton b : buttons) {
            b.render(ctx, textRenderer, mouseX, mouseY);
            b.renderTooltip(ctx, textRenderer, mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        fieldFocused = mouseX >= fieldX && mouseX < fieldX + fieldW && mouseY >= fieldY && mouseY < fieldY + fieldH;
        for (PushButton b : buttons) {
            if (b.click(mouseX, mouseY, button)) {
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (fieldFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !fieldText.isEmpty()) {
                fieldText = fieldText.substring(0, fieldText.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                fieldFocused = false;
                return true;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (fieldFocused && Character.isDigit(chr) && fieldText.length() < 6) {
            fieldText += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
