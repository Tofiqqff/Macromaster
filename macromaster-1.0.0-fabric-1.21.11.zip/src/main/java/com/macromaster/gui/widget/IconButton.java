package com.macromaster.gui.widget;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Small square button that draws a simple geometric icon (no font glyphs needed). */
public class IconButton extends PushButton {
    public enum Icon { UP, DOWN, COPY, EDIT, TRASH }

    public Icon icon;

    public IconButton(int x, int y, int size, Icon icon, Runnable onPress) {
        super(x, y, size, size, "", GHOST, onPress);
        this.icon = icon;
    }

    @Override
    public void render(DrawContext ctx, TextRenderer tr, int mx, int my) {
        super.render(ctx, tr, mx, my);
        if (!active) {
            return;
        }
        int cx = x + w / 2;
        int cy = y + h / 2;
        int c = (style == DANGER) ? 0xFFFFFFFF : (contains(mx, my) ? 0xFFE8EBF2 : 0xFF9AA3B5);
        switch (icon) {
            case UP:
                ctx.fill(cx - 1, cy - 3, cx + 1, cy, c);
                ctx.fill(cx - 3, cy - 1, cx + 3, cy + 1, c);
                ctx.fill(cx - 5, cy + 1, cx + 5, cy + 3, c);
                break;
            case DOWN:
                ctx.fill(cx - 5, cy - 3, cx + 5, cy - 1, c);
                ctx.fill(cx - 3, cy - 1, cx + 3, cy + 1, c);
                ctx.fill(cx - 1, cy + 1, cx + 1, cy + 3, c);
                break;
            case COPY:
                ctx.fill(cx + 1, cy - 4, cx + 5, cy, 0xFF9AA3B5);
                ctx.fill(cx - 5, cy - 2, cx - 1, cy + 2, c);
                ctx.fill(cx - 3, cy + 2, cx + 1, cy + 4, c);
                break;
            case EDIT:
                ctx.fill(cx - 4, cy + 2, cx - 2, cy + 4, c);
                ctx.fill(cx - 2, cy, cx, cy + 2, c);
                ctx.fill(cx, cy - 2, cx + 2, cy, c);
                ctx.fill(cx + 2, cy - 4, cx + 4, cy - 2, c);
                break;
            case TRASH:
                ctx.fill(cx - 3, cy - 4, cx + 3, cy - 3, c);
                ctx.fill(cx - 4, cy - 2, cx + 4, cy - 1, c);
                ctx.fill(cx - 3, cy, cx + 2, cy + 4, c);
                break;
        }
    }
}
