package com.macromaster.gui.widget;

import com.macromaster.gui.UiStyle;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Lightweight, hand-rendered button used across the MacroMaster GUI.
 * Deliberately not a vanilla ClickableWidget: full control over the dark theme,
 * hover states and hit-testing (screens render/click manually for precise layouts).
 */
public class PushButton {
    public static final int PRIMARY = 0;
    public static final int GHOST = 1;
    public static final int DANGER = 2;
    public static final int SUCCESS = 3;
    public static final int WARN = 4;

    public int x, y, w, h;
    public String label;
    public int style = GHOST;
    public boolean active = true;
    public String tooltip;
    public Runnable onPress;

    public PushButton(int x, int y, int w, int h, String label, int style, Runnable onPress) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.style = style;
        this.onPress = onPress;
    }

    public boolean contains(double mx, double my) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public void render(DrawContext ctx, TextRenderer tr, int mx, int my) {
        boolean hover = active && contains(mx, my);
        int bg;
        int border = UiStyle.BORDER;
        int text;
        switch (style) {
            case PRIMARY:
                bg = hover ? UiStyle.ACCENT : UiStyle.ACCENT_DARK;
                text = 0xFFFFFFFF;
                break;
            case SUCCESS:
                bg = hover ? UiStyle.GREEN : UiStyle.GREEN_DARK;
                text = 0xFFFFFFFF;
                break;
            case DANGER:
                bg = hover ? UiStyle.RED : UiStyle.RED_DARK;
                text = 0xFFFFFFFF;
                break;
            case WARN:
                bg = hover ? UiStyle.AMBER : 0xFF6B5426;
                text = 0xFF1A1408;
                break;
            default: // GHOST
                bg = hover ? UiStyle.PANEL_LIGHT : UiStyle.PANEL;
                text = hover ? UiStyle.TEXT : UiStyle.TEXT_DIM;
                break;
        }
        if (!active) {
            bg = 0xFF1A1D24;
            border = 0xFF262A33;
            text = 0xFF5A6272;
        }
        UiStyle.fillRounded(ctx, x, y, w, h, 3, bg);
        UiStyle.outline(ctx, x, y, w, h, border);
        ctx.drawCenteredText(tr, label, x + w / 2, y + (h - 8) / 2, text);
    }

    /** @return true if the click was consumed. */
    public boolean click(double mx, double my, int button) {
        if (active && button == 0 && contains(mx, my)) {
            if (onPress != null) {
                onPress.run();
            }
            return true;
        }
        return false;
    }

    public void renderTooltip(DrawContext ctx, TextRenderer tr, int mx, int my) {
        if (active && tooltip != null && contains(mx, my)) {
            ctx.drawTooltip(tr, java.util.List.of(net.minecraft.text.Text.literal(tooltip)), mx, my);
        }
    }
}
