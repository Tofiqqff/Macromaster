package com.macromaster.gui;

import com.macromaster.gui.widget.PushButton;
import com.macromaster.macro.MacroAction;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Grouped picker: Mouse / Keyboard / Timing action types. */
public class AddActionScreen extends Screen {
    private final Screen parent;
    private final List<Entry> entries = new ArrayList<>();

    private record Entry(String group, String label, String desc, MacroAction.Type type, PushButton button) {}

    public AddActionScreen(Screen parent) {
        super(Text.literal("Add Action"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        entries.clear();
        add("MOUSE", "Left Click", "One left mouse button click.", MacroAction.Type.LEFT_CLICK);
        add("MOUSE", "Right Click", "One right mouse button click.", MacroAction.Type.RIGHT_CLICK);
        add("KEYBOARD", "Key Press", "Press and release a key once.", MacroAction.Type.KEY_PRESS);
        add("KEYBOARD", "Key Hold", "Hold a key down for a duration (e.g. Shift 500 ms).", MacroAction.Type.KEY_HOLD);
        add("KEYBOARD", "Key Release", "Release a key that is currently held.", MacroAction.Type.KEY_RELEASE);
        add("TIMING", "Wait / Delay", "Pause before the next action (10 ms - 1000 ms+).", MacroAction.Type.WAIT);

        int y = 44;
        for (Entry e : entries) {
            e.button().x = width / 2 - 190;
            e.button().y = y;
            e.button().w = 380;
            e.button().h = 24;
            y += 28;
        }
    }

    private void add(String group, String label, String desc, MacroAction.Type type) {
        entries.add(new Entry(group, label, desc, type,
                new PushButton(0, 0, 0, 0, label, PushButton.GHOST, () ->
                        client.setScreen(new ActionEditScreen(parent, new MacroAction(type), true)))));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height, UiStyle.BG_TOP, UiStyle.BG_BOTTOM);
        ctx.drawCenteredText(textRenderer, "ADD ACTION", width / 2, 12, UiStyle.TEXT);
        ctx.drawCenteredText(textRenderer, "Choose an action type", width / 2, 24, UiStyle.TEXT_DIM);

        String lastGroup = null;
        for (Entry e : entries) {
            if (!e.group().equals(lastGroup)) {
                lastGroup = e.group();
                ctx.drawText(textRenderer, e.group(), e.button().x, e.button().y - 10, UiStyle.ACCENT, false);
            }
            e.button().render(ctx, textRenderer, mouseX, mouseY);
            ctx.drawText(textRenderer, e.desc(), e.button().x + e.button().w + 12, e.button().y + 8, UiStyle.TEXT_DIM, false);
        }

        PushButton back = new PushButton(width / 2 - 40, height - 30, 80, 20, "Back", PushButton.GHOST, this::close);
        back.render(ctx, textRenderer, mouseX, mouseY);
        back.renderTooltip(ctx, textRenderer, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (Entry e : entries) {
            if (e.button().click(mouseX, mouseY, button)) {
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
