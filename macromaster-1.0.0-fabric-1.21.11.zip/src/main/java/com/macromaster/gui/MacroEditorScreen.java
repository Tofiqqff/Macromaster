package com.macromaster.gui;

import com.macromaster.MacroMasterClient;
import com.macromaster.gui.widget.IconButton;
import com.macromaster.gui.widget.PushButton;
import com.macromaster.macro.Macro;
import com.macromaster.macro.MacroAction;
import com.macromaster.macro.MacroManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Macro editor: name, trigger key (with conflict warning), enabled state,
 * repeat mode + delay, and the ordered action list with
 * up/down/duplicate/edit/delete and unsaved-changes protection.
 */
public class MacroEditorScreen extends Screen {
    private final Screen parent;
    private final Macro original;
    private Macro working;
    private boolean isNew;

    private InputUtil.Key triggerKey;
    private String nameText = "";
    private String delayText = "0";
    private boolean nameFocused = false;
    private boolean delayFocused = false;

    private int nameX, nameY, nameW, nameH;
    private int delayX, delayY, delayW, delayH;

    private int scroll;
    private boolean dirty = false;
    private boolean confirmCancel = false;
    private boolean conflictArmed = false;

    private static final int DETAIL_H = 108;
    private static final int ROW_H = 24;

    public MacroEditorScreen(Screen parent, Macro macro) {
        super(Text.literal(macro == null ? "Create Macro" : "Edit Macro"));
        this.parent = parent;
        this.original = macro;
        if (macro == null) {
            this.isNew = true;
            this.working = new Macro();
            this.working.name = "";
        } else {
            this.working = macro.copy();
        }
        this.triggerKey = MacroAction.keyFromString(working.trigger);
        this.nameText = working.name;
        this.delayText = String.valueOf(working.repeatDelayMs);
    }

    public void addAction(MacroAction action) {
        working.actions.add(action);
        markDirty();
    }

    public void markDirty() {
        this.dirty = true;
    }

    private MacroManager manager() {
        return MacroMasterClient.manager();
    }

    @Override
    protected void init() {
        int x = 12;
        int w = width - 24;
        nameX = x + 64;
        nameY = 52;
        nameW = Math.min(220, w - 80);
        nameH = 16;

        delayX = x + w - 96;
        delayY = 90;
        delayW = 56;
        delayH = 16;
    }

    private int detailBottom() {
        return 48 + DETAIL_H;
    }

    private int actionsTop() {
        return detailBottom() + 18;
    }

    private int actionsBottom() {
        return height - 34;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height, UiStyle.BG_TOP, UiStyle.BG_BOTTOM);
        ctx.drawCenteredText(textRenderer, isNew ? "CREATE MACRO" : "EDIT MACRO", width / 2, 10, UiStyle.TEXT);

        int x = 12;
        int w = width - 24;

        // ---------- details panel ----------
        UiStyle.panel(ctx, x, 40, w, DETAIL_H);

        // name
        ctx.drawText(textRenderer, "Name:", x + 12, nameY + 4, UiStyle.TEXT_DIM, false);
        UiStyle.fillRounded(ctx, nameX, nameY, nameW, nameH, 2, 0xFF101318);
        UiStyle.outline(ctx, nameX, nameY, nameW, nameH, nameFocused ? UiStyle.ACCENT : UiStyle.BORDER);
        ctx.drawText(textRenderer, nameText + (nameFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""),
                nameX + 4, nameY + 4, UiStyle.TEXT, false);

        // enabled toggle
        int togX = x + w - 84;
        PushButton enabledBtn = new PushButton(togX, nameY - 2, 72, 20, working.enabled ? "ENABLED" : "DISABLED",
                working.enabled ? PushButton.SUCCESS : PushButton.GHOST,
                () -> {
                    working.enabled = !working.enabled;
                    markDirty();
                });
        enabledBtn.render(ctx, textRenderer, mouseX, mouseY);

        // trigger
        ctx.drawText(textRenderer, "Trigger:", x + 12, 78, UiStyle.TEXT_DIM, false);
        String keyLabel = triggerKey.getLocalizedText().getString();
        PushButton triggerBtn = new PushButton(x + 64, 73, 90, 20, keyLabel, PushButton.PRIMARY,
                () -> client.setScreen(new KeyCaptureScreen(this, k -> {
                    triggerKey = k;
                    conflictArmed = false;
                    markDirty();
                })));
        triggerBtn.render(ctx, textRenderer, mouseX, mouseY);
        triggerBtn.tooltip = "Click, then press any key or mouse button";
        triggerBtn.renderTooltip(ctx, textRenderer, mouseX, mouseY);

        // conflict warning
        Macro conflict = manager().findTriggerConflict(working, triggerKey);
        if (conflict != null) {
            ctx.drawText(textRenderer, "Same trigger as \"" + conflict.name + "\"",
                    x + 166, 78, UiStyle.AMBER, false);
        }

        // repeat mode
        ctx.drawText(textRenderer, "Repeat:", x + 12, 104, UiStyle.TEXT_DIM, false);
        PushButton modeBtn = new PushButton(x + 64, 99, 120, 20, working.mode().label, PushButton.GHOST, () -> {
            working.repeatMode = working.mode().next().name();
            markDirty();
        });
        modeBtn.render(ctx, textRenderer, mouseX, mouseY);
        modeBtn.tooltip = "Run Once: fires one time. Toggle: press to start, press again to stop. Hold: runs while the key is held.";
        modeBtn.renderTooltip(ctx, textRenderer, mouseX, mouseY);

        // repeat delay
        if (working.mode() != Macro.RepeatMode.ONCE) {
            ctx.drawText(textRenderer, "Repeat delay (ms):", delayX - 110, delayY + 4, UiStyle.TEXT_DIM, false);
            UiStyle.fillRounded(ctx, delayX, delayY, delayW, delayH, 2, 0xFF101318);
            UiStyle.outline(ctx, delayX, delayY, delayW, delayH, delayFocused ? UiStyle.ACCENT : UiStyle.BORDER);
            ctx.drawText(textRenderer,
                    delayText + (delayFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""),
                    delayX + 4, delayY + 4, UiStyle.TEXT, false);
        }

        // ---------- actions list ----------
        int at = actionsTop();
        ctx.drawText(textRenderer, "ACTIONS (" + working.actions.size() + ")", x + 4, at - 12, UiStyle.ACCENT, false);
        PushButton addBtn = new PushButton(x + w - 120, at - 17, 120, 20, "+ Add Action", PushButton.PRIMARY,
                () -> client.setScreen(new AddActionScreen(this)));
        addBtn.render(ctx, textRenderer, mouseX, mouseY);

        UiStyle.fillRounded(ctx, x, at, w, actionsBottom() - at, 4, 0x66101418);
        UiStyle.outline(ctx, x, at, w, actionsBottom() - at, UiStyle.BORDER);

        ctx.enableScissor(x, at, x + w, actionsBottom());
        int y = at + 4 - scroll;
        int idx = 0;
        for (MacroAction a : working.actions) {
            renderActionRow(ctx, a, idx, x + 4, y, w - 8, mouseX, mouseY);
            y += ROW_H;
            idx++;
        }
        if (working.actions.isEmpty()) {
            ctx.drawCenteredText(textRenderer, "No actions. Add one with \"+ Add Action\".", width / 2, at + 18,
                    UiStyle.TEXT_DIM);
        }
        ctx.disableScissor();

        // ---------- footer ----------
        ctx.fill(0, height - 30, width, height, 0xC0101115);
        ctx.fill(0, height - 30, width, height - 29, UiStyle.BORDER);
        PushButton save = new PushButton(width - 12 - 90, height - 26, 90, 20,
                conflictArmed && conflict != null ? "Save anyway" : "Save", PushButton.PRIMARY, this::save);
        PushButton cancel = new PushButton(width - 12 - 90 - 96, height - 26, 90, 20, "Cancel", PushButton.GHOST,
                this::requestClose);
        save.render(ctx, textRenderer, mouseX, mouseY);
        cancel.render(ctx, textRenderer, mouseX, mouseY);

        if (confirmCancel) {
            renderConfirmDiscard(ctx, mouseX, mouseY);
        }
    }

    private void renderActionRow(DrawContext ctx, MacroAction a, int idx, int x, int y, int w, int mx, int my) {
        boolean hover = my >= y && my < y + ROW_H - 2;
        if (hover) {
            UiStyle.fillRounded(ctx, x, y, w, ROW_H - 2, 3, UiStyle.PANEL_LIGHT);
        }
        ctx.drawText(textRenderer, (idx + 1) + ".", x + 6, y + 6, UiStyle.TEXT_DIM, false);
        String summary = a.summary();
        int maxW = w - 210;
        while (textRenderer.getWidth(summary) > maxW && summary.length() > 4) {
            summary = summary.substring(0, summary.length() - 2);
        }
        if (!summary.equals(a.summary())) {
            summary += "..";
        }
        ctx.drawText(textRenderer, summary, x + 28, y + 6, UiStyle.TEXT, false);

        int by = y + 1;
        int bh = ROW_H - 4;
        int bx = x + w - 4;
        IconButton del = new IconButton(bx - 22, by, bh, IconButton.Icon.TRASH, () -> {
            working.actions.remove(idx);
            markDirty();
        });
        IconButton edit = new IconButton(bx - 48, by, bh, IconButton.Icon.EDIT, () ->
                client.setScreen(new ActionEditScreen(this, a, false)));
        IconButton dup = new IconButton(bx - 74, by, bh, IconButton.Icon.COPY, () -> {
            working.actions.add(idx + 1, a.copy());
            markDirty();
        });
        IconButton down = new IconButton(bx - 100, by, bh, IconButton.Icon.DOWN, () -> {
            if (idx < working.actions.size() - 1) {
                working.actions.add(idx + 1, working.actions.remove(idx));
                markDirty();
            }
        });
        IconButton up = new IconButton(bx - 126, by, bh, IconButton.Icon.UP, () -> {
            if (idx > 0) {
                working.actions.add(idx - 1, working.actions.remove(idx));
                markDirty();
            }
        });
        del.style = PushButton.DANGER;
        up.active = idx > 0;
        down.active = idx < working.actions.size() - 1;
        up.render(ctx, textRenderer, mx, my);
        down.render(ctx, textRenderer, mx, my);
        dup.render(ctx, textRenderer, mx, my);
        edit.render(ctx, textRenderer, mx, my);
        del.render(ctx, textRenderer, mx, my);
    }

    private void renderConfirmDiscard(DrawContext ctx, int mx, int my) {
        ctx.fill(0, 0, width, height, 0x80000000);
        int pw = 300, ph = 84;
        int px = (width - pw) / 2, py = (height - ph) / 2;
        UiStyle.panel(ctx, px, py, pw, ph);
        ctx.drawCenteredText(textRenderer, "Discard unsaved changes?", width / 2, py + 16, UiStyle.TEXT);
        PushButton yes = new PushButton(px + pw / 2 - 130, py + ph - 30, 120, 20, "Discard", PushButton.DANGER, () -> {
            confirmCancel = false;
            client.setScreen(parent);
        });
        PushButton no = new PushButton(px + pw / 2 + 10, py + ph - 30, 120, 20, "Keep editing", PushButton.GHOST,
                () -> confirmCancel = false);
        yes.render(ctx, textRenderer, mx, my);
        no.render(ctx, textRenderer, mx, my);
    }

    private void save() {
        Macro conflict = manager().findTriggerConflict(working, triggerKey);
        if (conflict != null && !conflictArmed) {
            conflictArmed = true; // user must confirm once
            return;
        }
        working.name = nameText.trim().isEmpty() ? "Unnamed Macro" : nameText.trim();
        try {
            working.repeatDelayMs = Math.max(0, Math.min(60000, Integer.parseInt(delayText.trim())));
        } catch (NumberFormatException e) {
            working.repeatDelayMs = 0;
        }
        working.trigger = MacroAction.keyToString(triggerKey);

        if (isNew) {
            manager().addMacro(working);
        } else {
            original.name = working.name;
            original.enabled = working.enabled;
            original.repeatMode = working.repeatMode;
            original.repeatDelayMs = working.repeatDelayMs;
            original.actions = working.actions;
            manager().updateTrigger(original, triggerKey);
            manager().persist();
        }
        client.setScreen(parent);
    }

    private void requestClose() {
        if (dirty) {
            confirmCancel = true;
        } else {
            client.setScreen(parent);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (confirmCancel) {
            int pw = 300, ph = 84;
            int px = (width - pw) / 2, py = (height - ph) / 2;
            PushButton yes = new PushButton(px + pw / 2 - 130, py + ph - 30, 120, 20, "Discard", PushButton.DANGER,
                    () -> {
                        confirmCancel = false;
                        client.setScreen(parent);
                    });
            PushButton no = new PushButton(px + pw / 2 + 10, py + ph - 30, 120, 20, "Keep editing", PushButton.GHOST,
                    () -> confirmCancel = false);
            if (yes.click(mouseX, mouseY, button) || no.click(mouseX, mouseY, button)) {
                return true;
            }
            return true;
        }

        nameFocused = in(nameX, nameY, nameW, nameH, mouseX, mouseY);
        delayFocused = working.mode() != Macro.RepeatMode.ONCE && in(delayX, delayY, delayW, delayH, mouseX, mouseY);

        int x = 12;
        int w = width - 24;
        int togX = x + w - 84;
        if (new PushButton(togX, 50, 72, 20, "", 0, () -> {
            working.enabled = !working.enabled;
            markDirty();
        }).click(mouseX, mouseY, button)) {
            return true;
        }
        if (new PushButton(x + 64, 73, 90, 20, "", 0, () -> client.setScreen(new KeyCaptureScreen(this, k -> {
            triggerKey = k;
            conflictArmed = false;
            markDirty();
        }))).click(mouseX, mouseY, button)) {
            return true;
        }
        if (new PushButton(x + 64, 99, 120, 20, "", 0, () -> {
            working.repeatMode = working.mode().next().name();
            markDirty();
        }).click(mouseX, mouseY, button)) {
            return true;
        }
        int at = actionsTop();
        if (new PushButton(x + w - 120, at - 17, 120, 20, "", 0,
                () -> client.setScreen(new AddActionScreen(this))).click(mouseX, mouseY, button)) {
            return true;
        }

        // action rows
        int y = at + 4 - scroll;
        for (int idx = 0; idx < working.actions.size(); idx++) {
            if (mouseY >= y && mouseY < y + ROW_H - 2) {
                MacroAction a = working.actions.get(idx);
                int bh = ROW_H - 4;
                int bx = x + 4 + w - 8 - 4;
                IconButton del = new IconButton(bx - 22, y + 1, bh, IconButton.Icon.TRASH, () -> {
                    working.actions.remove(idx);
                    markDirty();
                });
                IconButton edit = new IconButton(bx - 48, y + 1, bh, IconButton.Icon.EDIT, () ->
                        client.setScreen(new ActionEditScreen(this, a, false)));
                IconButton dup = new IconButton(bx - 74, y + 1, bh, IconButton.Icon.COPY, () -> {
                    working.actions.add(idx + 1, a.copy());
                    markDirty();
                });
                IconButton down = new IconButton(bx - 100, y + 1, bh, IconButton.Icon.DOWN, () -> {
                    if (idx < working.actions.size() - 1) {
                        working.actions.add(idx + 1, working.actions.remove(idx));
                        markDirty();
                    }
                });
                IconButton up = new IconButton(bx - 126, y + 1, bh, IconButton.Icon.UP, () -> {
                    if (idx > 0) {
                        working.actions.add(idx - 1, working.actions.remove(idx));
                        markDirty();
                    }
                });
                if (up.click(mouseX, mouseY, button) || down.click(mouseX, mouseY, button)
                        || dup.click(mouseX, mouseY, button) || edit.click(mouseX, mouseY, button)
                        || del.click(mouseX, mouseY, button)) {
                    return true;
                }
                return false;
            }
            y += ROW_H;
        }

        // footer
        Macro conflict = manager().findTriggerConflict(working, triggerKey);
        PushButton save = new PushButton(width - 12 - 90, height - 26, 90, 20, "", 0, this::save);
        PushButton cancel = new PushButton(width - 12 - 90 - 96, height - 26, 90, 20, "", 0, this::requestClose);
        if (save.click(mouseX, mouseY, button) || cancel.click(mouseX, mouseY, button)) {
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean in(int x, int y, int w, int h, double mx, double my) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int contentH = working.actions.size() * ROW_H + 8;
        int viewH = actionsBottom() - actionsTop();
        int max = Math.max(0, contentH - viewH);
        scroll = (int) Math.max(0, Math.min(max, scroll - verticalAmount * 16));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (nameFocused || delayFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (nameFocused && !nameText.isEmpty()) {
                    nameText = nameText.substring(0, nameText.length() - 1);
                    markDirty();
                }
                if (delayFocused && !delayText.isEmpty()) {
                    delayText = delayText.substring(0, delayText.length() - 1);
                    markDirty();
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                nameFocused = false;
                delayFocused = false;
                return true;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            requestClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (nameFocused && nameText.length() < 32 && isAllowedNameChar(chr)) {
            nameText += chr;
            markDirty();
            return true;
        }
        if (delayFocused && Character.isDigit(chr) && delayText.length() < 6) {
            delayText += chr;
            markDirty();
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private boolean isAllowedNameChar(char c) {
        return c >= 32 && c != '%' && c != '\\';
    }

    @Override
    public void close() {
        requestClose();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
