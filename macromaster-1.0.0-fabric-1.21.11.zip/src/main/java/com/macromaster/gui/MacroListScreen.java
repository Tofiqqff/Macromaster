package com.macromaster.gui;

import com.macromaster.MacroMasterClient;
import com.macromaster.gui.widget.PushButton;
import com.macromaster.macro.Macro;
import com.macromaster.macro.MacroAction;
import com.macromaster.macro.MacroManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Main "Macro Manager" screen: scrollable list of macro cards with
 * status dot, name, trigger, action count, enable-toggle, edit and delete.
 */
public class MacroListScreen extends Screen {
    private static final int HEADER_H = 36;
    private static final int FOOTER_H = 40;
    private static final int CARD_H = 46;
    private static final int CARD_GAP = 6;

    private final Screen parent;
    private final List<PushButton> footerButtons = new ArrayList<>();
    private int scroll;
    private Macro pendingDelete;
    private int cardTopY;
    private int listBottom;

    public MacroListScreen(Screen parent) {
        super(Text.literal("Macro Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        footerButtons.clear();
        int by = height - 30;
        footerButtons.add(new PushButton(12, by, 150, 20, "+ Create Macro", PushButton.PRIMARY,
                () -> client.setScreen(new MacroEditorScreen(this, null))));
        footerButtons.add(new PushButton(width - 12 - 80, by, 80, 20, "Settings", PushButton.GHOST,
                () -> client.setScreen(new SettingsScreen(this))));
        footerButtons.add(new PushButton(width - 12 - 80 - 86, by, 80, 20, "Close", PushButton.GHOST, this::close));
        cardTopY = HEADER_H + 4;
        listBottom = height - FOOTER_H - 2;
    }

    private MacroManager manager() {
        return MacroMasterClient.manager();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height, UiStyle.BG_TOP, UiStyle.BG_BOTTOM);

        // Header
        ctx.drawCenteredText(textRenderer, "MACRO MANAGER", width / 2, 10, UiStyle.TEXT);
        MacroManager m = manager();
        int running = m.executor().runningCount();
        ctx.drawCenteredText(textRenderer,
                m.macros().size() + " macro(s)  -  " + running + " running  -  emergency: "
                        + m.settings().emergencyKey().getLocalizedText().getString(),
                width / 2, 22, UiStyle.TEXT_DIM);
        ctx.fill(0, HEADER_H, width, HEADER_H + 1, UiStyle.BORDER);

        // List
        ctx.enableScissor(0, cardTopY, width, listBottom);
        int y = cardTopY - scroll;
        for (Macro macro : m.macros()) {
            renderCard(ctx, macro, 12, y, width - 24, mouseX, mouseY);
            y += CARD_H + CARD_GAP;
        }
        if (m.macros().isEmpty()) {
            ctx.drawCenteredText(textRenderer, "No macros yet. Press \"+ Create Macro\" to begin.",
                    width / 2, cardTopY + 24, UiStyle.TEXT_DIM);
        }
        ctx.disableScissor();

        // Footer
        ctx.fill(0, height - FOOTER_H, width, height, 0xC0101115);
        ctx.fill(0, height - FOOTER_H, width, height - FOOTER_H + 1, UiStyle.BORDER);
        for (PushButton b : footerButtons) {
            b.render(ctx, textRenderer, mouseX, mouseY);
            b.renderTooltip(ctx, textRenderer, mouseX, mouseY);
        }

        if (pendingDelete != null) {
            renderDeleteConfirm(ctx, mouseX, mouseY);
        }
    }

    private void renderCard(DrawContext ctx, Macro macro, int x, int y, int w, int mx, int my) {
        UiStyle.panel(ctx, x, y, w, CARD_H);

        // Status dot
        boolean running = macro.runtime.running;
        UiStyle.dot(ctx, x + 10, y + CARD_H / 2 - 3, 6, running ? UiStyle.GREEN : (macro.enabled ? 0xFF3A8C4E : 0xFF565D6B));

        // Name
        String name = macro.name.isEmpty() ? "Unnamed Macro" : macro.name;
        UiStyle.boldText(ctx, textRenderer, name, x + 24, y + 8, macro.enabled ? UiStyle.TEXT : UiStyle.TEXT_DIM);

        // Meta line
        String keyName = MacroAction.keyFromString(macro.trigger).getLocalizedText().getString();
        String meta = "Key: " + keyName + "   Actions: " + macro.actions.size() + "   Mode: " + macro.mode().label;
        ctx.drawText(textRenderer, meta, x + 24, y + 24, UiStyle.TEXT_DIM, false);

        // Conflict hint
        InputUtil.Key trig = MacroAction.keyFromString(macro.trigger);
        Macro other = manager().findTriggerConflict(macro, trig);
        if (other != null) {
            ctx.drawText(textRenderer, "Conflicts with \"" + other.name + "\"", x + 24, y + 34, UiStyle.AMBER, false);
        }

        // Right side buttons
        int by = y + (CARD_H - 20) / 2;
        int delX = x + w - 12 - 58;
        int editX = delX - 64;
        int togX = editX - 70;

        PushButton toggle = new PushButton(togX, by, 64, 20, macro.enabled ? "ON" : "OFF",
                macro.enabled ? PushButton.SUCCESS : PushButton.GHOST,
                () -> {
                    macro.enabled = !macro.enabled;
                    if (!macro.enabled) {
                        manager().executor().stop(macro);
                    }
                    manager().persist();
                });
        PushButton edit = new PushButton(editX, by, 58, 20, "Edit", PushButton.GHOST,
                () -> client.setScreen(new MacroEditorScreen(this, macro)));
        PushButton del = new PushButton(delX, by, 58, 20, "Delete", PushButton.DANGER, () -> pendingDelete = macro);

        toggle.render(ctx, textRenderer, mx, my);
        edit.render(ctx, textRenderer, mx, my);
        del.render(ctx, textRenderer, mx, my);
    }

    private void renderDeleteConfirm(DrawContext ctx, int mx, int my) {
        ctx.fill(0, 0, width, height, 0x80000000);
        int pw = 300, ph = 90;
        int px = (width - pw) / 2, py = (height - ph) / 2;
        UiStyle.panel(ctx, px, py, pw, ph);
        ctx.drawCenteredText(textRenderer, "Delete macro \"" + pendingDelete.name + "\"?", width / 2, py + 16, UiStyle.TEXT);
        ctx.drawCenteredText(textRenderer, "This cannot be undone.", width / 2, py + 30, UiStyle.TEXT_DIM);
        PushButton yes = new PushButton(px + pw / 2 - 130, py + ph - 30, 120, 20, "Delete", PushButton.DANGER, () -> {
            manager().deleteMacro(pendingDelete);
            pendingDelete = null;
        });
        PushButton no = new PushButton(px + pw / 2 + 10, py + ph - 30, 120, 20, "Cancel", PushButton.GHOST,
                () -> pendingDelete = null);
        yes.render(ctx, textRenderer, mx, my);
        no.render(ctx, textRenderer, mx, my);
        yes.renderTooltip(ctx, textRenderer, mx, my);
        no.renderTooltip(ctx, textRenderer, mx, my);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (pendingDelete != null) {
            int pw = 300, ph = 90;
            int px = (width - pw) / 2, py = (height - ph) / 2;
            PushButton yes = new PushButton(px + pw / 2 - 130, py + ph - 30, 120, 20, "Delete", PushButton.DANGER, () -> {
                manager().deleteMacro(pendingDelete);
                pendingDelete = null;
            });
            PushButton no = new PushButton(px + pw / 2 + 10, py + ph - 30, 120, 20, "Cancel", PushButton.GHOST,
                    () -> pendingDelete = null);
            if (yes.click(mouseX, mouseY, button) || no.click(mouseX, mouseY, button)) {
                return true;
            }
            return true; // modal: swallow all other clicks
        }

        // Card buttons
        MacroManager m = manager();
        int y = cardTopY - scroll;
        for (Macro macro : m.macros()) {
            if (mouseY >= y && mouseY < y + CARD_H) {
                int x = 12, w = width - 24;
                int by = y + (CARD_H - 20) / 2;
                int delX = x + w - 12 - 58;
                int editX = delX - 64;
                int togX = editX - 70;
                PushButton toggle = new PushButton(togX, by, 64, 20, "", 0, () -> {
                    macro.enabled = !macro.enabled;
                    if (!macro.enabled) m.executor().stop(macro);
                    m.persist();
                });
                PushButton edit = new PushButton(editX, by, 58, 20, "", 0,
                        () -> client.setScreen(new MacroEditorScreen(this, macro)));
                PushButton del = new PushButton(delX, by, 58, 20, "", 0, () -> pendingDelete = macro);
                if (toggle.click(mouseX, mouseY, button) || edit.click(mouseX, mouseY, button)
                        || del.click(mouseX, mouseY, button)) {
                    return true;
                }
                return false;
            }
            y += CARD_H + CARD_GAP;
        }

        for (PushButton b : footerButtons) {
            if (b.click(mouseX, mouseY, button)) {
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int contentH = manager().macros().size() * (CARD_H + CARD_GAP);
        int viewH = listBottom - cardTopY;
        int max = Math.max(0, contentH - viewH);
        scroll = (int) Math.max(0, Math.min(max, scroll - verticalAmount * 16));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
