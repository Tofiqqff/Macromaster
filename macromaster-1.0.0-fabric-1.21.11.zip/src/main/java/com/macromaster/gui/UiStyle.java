package com.macromaster.gui;

import net.minecraft.client.gui.DrawContext;

/**
 * Shared dark design language: colors + shape helpers.
 * Rounded corners are faked with two overlapping fills (cheap, crisp at any GUI scale).
 */
public final class UiStyle {
    public static final int BG_TOP = 0xF0101116;
    public static final int BG_BOTTOM = 0xF0141820;
    public static final int PANEL = 0xFF1E222B;
    public static final int PANEL_LIGHT = 0xFF262C38;
    public static final int ROW_HOVER = 0x2AFFFFFF;
    public static final int BORDER = 0xFF343B49;
    public static final int ACCENT = 0xFF4F8CFF;
    public static final int ACCENT_DARK = 0xFF2C4E91;
    public static final int TEXT = 0xFFE8EBF2;
    public static final int TEXT_DIM = 0xFF9AA3B5;
    public static final int GREEN = 0xFF43C465;
    public static final int GREEN_DARK = 0xFF1E4D2E;
    public static final int RED = 0xFFE05656;
    public static final int RED_DARK = 0xFF5A2424;
    public static final int AMBER = 0xFFE5B567;

    private UiStyle() {
    }

    /** Rounded rectangle using two overlapping fills. */
    public static void fillRounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (r <= 0 || w < 8 || h < 8) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        r = Math.min(r, Math.min(w, h) / 2);
        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void outline(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** Small square "dot" with rounded corners, used as a status indicator. */
    public static void dot(DrawContext ctx, int x, int y, int size, int color) {
        fillRounded(ctx, x, y, size, size, size / 2, color);
    }

    public static void panel(DrawContext ctx, int x, int y, int w, int h) {
        fillRounded(ctx, x, y, w, h, 4, PANEL);
        outline(ctx, x, y, w, h, BORDER);
    }

    /** Draws text twice with a 1px offset for a bold look without matrix scaling. */
    public static void boldText(DrawContext ctx, net.minecraft.client.font.TextRenderer tr,
                                String s, int x, int y, int color) {
        ctx.drawText(tr, s, x + 1, y, color, false);
        ctx.drawText(tr, s, x, y, color, false);
    }
}
