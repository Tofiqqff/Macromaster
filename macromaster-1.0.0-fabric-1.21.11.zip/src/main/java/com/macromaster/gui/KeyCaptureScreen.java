package com.macromaster.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;

/**
 * Captures the next keyboard or mouse input and hands it to the callback.
 * While this screen is open no macro can run (the manager halts macros whenever
 * any screen is open), so captured keys never accidentally fire macro actions.
 */
public class KeyCaptureScreen extends Screen {
    private final Screen parent;
    private final Consumer<InputUtil.Key> callback;

    public KeyCaptureScreen(Screen parent, Consumer<InputUtil.Key> callback) {
        super(Text.literal("Press any key"));
        this.parent = parent;
        this.callback = callback;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (parent != null) {
            parent.render(ctx, mouseX, mouseY, delta);
        } else {
            ctx.fillGradient(0, 0, width, height, UiStyle.BG_TOP, UiStyle.BG_BOTTOM);
        }
        ctx.fill(0, 0, width, height, 0x90000000);

        int pw = 300, ph = 92;
        int px = (width - pw) / 2, py = (height - ph) / 2;
        UiStyle.panel(ctx, px, py, pw, ph);
        ctx.drawCenteredText(textRenderer, "Press any key or mouse button", width / 2, py + 22, UiStyle.TEXT);
        ctx.drawCenteredText(textRenderer, "ESC - cancel", width / 2, py + 40, UiStyle.TEXT_DIM);
        ctx.drawCenteredText(textRenderer, "MacroMaster", width / 2, py + 66, 0xFF4F8CFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        callback.accept(InputUtil.Type.KEYSYM.createFromCode(keyCode));
        close();
        return true;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        callback.accept(InputUtil.Type.MOUSE.createFromCode(button));
        close();
        return true;
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
