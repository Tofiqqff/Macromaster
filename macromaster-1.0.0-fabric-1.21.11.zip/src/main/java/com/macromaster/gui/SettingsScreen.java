package com.macromaster.gui;

import com.macromaster.MacroMasterClient;
import com.macromaster.gui.widget.PushButton;
import com.macromaster.macro.MacroManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Global settings: manager key, emergency stop key, HUD toggle. */
public class SettingsScreen extends Screen {
    private final Screen parent;
    private final List<PushButton> buttons = new ArrayList<>();

    public SettingsScreen(Screen parent) {
        super(Text.literal("MacroMaster Settings"));
        this.parent = parent;
    }

    private MacroManager manager() {
        return MacroMasterClient.manager();
    }

    @Override
    protected void init() {
        buttons.clear();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height, UiStyle.BG_TOP, UiStyle.BG_BOTTOM);
        ctx.drawCenteredText(textRenderer, "SETTINGS", width / 2, 12, UiStyle.TEXT);

        int pw = Math.min(380, width - 24);
        int px = width / 2 - pw / 2;
        int py = 44;
        UiStyle.panel(ctx, px, py, pw, 132);

        MacroManager m = manager();

        // Manager key
        ctx.drawText(textRenderer, "Manager key:", px + 14, py + 16, UiStyle.TEXT_DIM, false);
        PushButton mgr = new PushButton(px + pw - 130, py + 10, 116, 20,
                m.settings().managerKey().getLocalizedText().getString(), PushButton.PRIMARY,
                () -> client.setScreen(new KeyCaptureScreen(this, k -> {
                    m.setManagerKey(k);
                })));
        mgr.tooltip = "Opens the Macro Manager";
        mgr.render(ctx, textRenderer, mouseX, mouseY);
        mgr.renderTooltip(ctx, textRenderer, mouseX, mouseY);

        // Emergency key
        ctx.drawText(textRenderer, "Emergency stop:", px + 14, py + 48, UiStyle.TEXT_DIM, false);
        PushButton emg = new PushButton(px + pw - 130, py + 42, 116, 20,
                m.settings().emergencyKey().getLocalizedText().getString(), PushButton.WARN,
                () -> client.setScreen(new KeyCaptureScreen(this, k -> {
                    m.setEmergencyKey(k);
                })));
        emg.tooltip = "Instantly stops every running macro and releases all keys";
        emg.render(ctx, textRenderer, mouseX, mouseY);
        emg.renderTooltip(ctx, textRenderer, mouseX, mouseY);

        // HUD toggle
        ctx.drawText(textRenderer, "HUD indicator:", px + 14, py + 80, UiStyle.TEXT_DIM, false);
        PushButton hud = new PushButton(px + pw - 130, py + 74, 116, 20,
                m.settings().hudEnabled ? "ON" : "OFF",
                m.settings().hudEnabled ? PushButton.SUCCESS : PushButton.GHOST,
                () -> {
                    m.settings().hudEnabled = !m.settings().hudEnabled;
                    m.persist();
                });
        hud.tooltip = "Shows running macros in the top-right corner";
        hud.render(ctx, textRenderer, mouseX, mouseY);
        hud.renderTooltip(ctx, textRenderer, mouseX, mouseY);

        ctx.drawText(textRenderer, "Config file: config/macromaster.json", px + 14, py + 110, UiStyle.TEXT_DIM, false);

        PushButton done = new PushButton(width / 2 - 50, height - 32, 100, 22, "Done", PushButton.PRIMARY, this::close);
        done.render(ctx, textRenderer, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        MacroManager m = manager();
        int pw = Math.min(380, width - 24);
        int px = width / 2 - pw / 2;
        int py = 44;
        if (new PushButton(px + pw - 130, py + 10, 116, 20, "", 0,
                () -> client.setScreen(new KeyCaptureScreen(this, k -> m.setManagerKey(k))))
                .click(mouseX, mouseY, button)) {
            return true;
        }
        if (new PushButton(px + pw - 130, py + 42, 116, 20, "", 0,
                () -> client.setScreen(new KeyCaptureScreen(this, k -> m.setEmergencyKey(k))))
                .click(mouseX, mouseY, button)) {
            return true;
        }
        if (new PushButton(px + pw - 130, py + 74, 116, 20, "", 0, () -> {
            m.settings().hudEnabled = !m.settings().hudEnabled;
            m.persist();
        }).click(mouseX, mouseY, button)) {
            return true;
        }
        if (new PushButton(width / 2 - 50, height - 32, 100, 22, "", 0, this::close).click(mouseX, mouseY, button)) {
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
