package com.macromaster;

import com.macromaster.hud.MacroHud;
import com.macromaster.macro.MacroManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MacroMasterClient implements ClientModInitializer {
    public static final String MOD_ID = "macromaster";
    public static final Logger LOGGER = LoggerFactory.getLogger("MacroMaster");

    private static MacroManager manager;

    public static MacroManager manager() {
        return manager;
    }

    @Override
    public void onInitializeClient() {
        manager = new MacroManager();
        manager.init();

        ClientTickEvents.END_CLIENT_TICK.register(manager::onTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> manager.shutdown());

        MacroHud.register();
        LOGGER.info("MacroMaster initialized: {} macro(s) loaded.", manager.macros().size());
    }
}
