package com.macromaster.hud;

import com.macromaster.MacroMasterClient;
import com.macromaster.macro.Macro;
import com.macromaster.macro.MacroManager;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DeltaTracker;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Small, non-intrusive status HUD (top-right) listing running macros.
 * Uses the modern HudElementRegistry API (HudRenderCallback was removed in 1.21.8+).
 */
public final class MacroHud {
    private MacroHud() {
    }

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(MacroMasterClient.MOD_ID, "status_hud"),
                MacroHud::render);
    }

    private static void render(net.fabricmc.fabric.api.client.rendering.v1.hud.GuiGraphicsExtractor graphics,
                               DeltaTracker tickCounter) {
        MacroManager manager = MacroMasterClient.manager();
        if (manager == null || !manager.settings().hudEnabled) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<Macro> running = new ArrayList<>();
        for (Macro m : manager.macros()) {
            if (m.runtime.running) {
                running.add(m);
            }
        }
        if (running.isEmpty()) {
            return;
        }

        net.minecraft.client.font.TextRenderer tr = client.textRenderer;
        int maxW = 0;
        for (Macro m : running) {
            maxW = Math.max(maxW, tr.getWidth("Macro: " + m.name));
        }
        int w = maxW + 14;
        int h = running.size() * 11 + 8;
        int x = client.getWindow().getScaledWidth() - w - 6;
        int y = 6;

        graphics.fill(x, y, x + w, y + h, 0xB0101319);
        // top accent line
        graphics.fill(x, y, x + w, y + 1, 0xFF4F8CFF);

        int ty = y + 5;
        for (Macro m : running) {
            String line = "Macro: " + m.name;
            graphics.drawText(tr, line, x + 7, ty, 0xFFE8EBF2, false);
            ty += 11;
        }
    }
}
