package com.macromaster.macro;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * JSON persistence for macros and settings (config/macromaster.json).
 * Missing file -> defaults. Corrupt file -> backed up and replaced with defaults.
 */
public final class MacroConfig {
    private static final int VERSION = 1;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private MacroConfig() {
    }

    public static void load(MacroManager manager) {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("macromaster.json");
        manager.macros().clear();
        try {
            if (!Files.exists(file)) {
                manager.setSettings(new MacroSettings());
                return;
            }
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("settings")) {
                MacroSettings s = GSON.fromJson(root.get("settings"), MacroSettings.class);
                manager.setSettings(s != null ? s : new MacroSettings());
            } else {
                manager.setSettings(new MacroSettings());
            }
            if (root.has("macros")) {
                Macro[] arr = GSON.fromJson(root.get("macros"), Macro[].class);
                if (arr != null) {
                    for (Macro m : arr) {
                        if (m != null && m.id != null) {
                            if (m.actions == null) m.actions = new java.util.ArrayList<>();
                            if (m.runtime == null) m.runtime = new Macro.RuntimeState();
                            manager.macros().add(m);
                        }
                    }
                }
            }
        } catch (Exception e) {
            try {
                Path backup = file.resolveSibling("macromaster-corrupt-" + System.currentTimeMillis() + ".json");
                Files.move(file, backup, StandardCopyOption.REPLACE_EXISTING);
                com.macromaster.MacroMasterClient.LOGGER
                        .warn("MacroMaster config was corrupt; it was backed up to {}", backup.getFileName(), e);
            } catch (IOException ignored) {
            }
            manager.macros().clear();
            manager.setSettings(new MacroSettings());
        }
    }

    public static void save(MacroManager manager) {
        try {
            JsonObject root = new JsonObject();
            root.addProperty("version", VERSION);
            root.add("settings", GSON.toJsonTree(manager.settings()));
            root.add("macros", GSON.toJsonTree(manager.macros()));
            Path file = FabricLoader.getInstance().getConfigDir().resolve("macromaster.json");
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(root));
        } catch (Exception e) {
            com.macromaster.MacroMasterClient.LOGGER.error("Failed to save MacroMaster config", e);
        }
    }
}
