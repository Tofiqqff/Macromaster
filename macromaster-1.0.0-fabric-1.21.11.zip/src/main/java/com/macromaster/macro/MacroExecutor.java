package com.macromaster.macro;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.Iterator;
import java.util.List;

/**
 * Single-threaded, tick-driven macro engine.
 *
 * Design notes:
 * - No threads, no Thread.sleep(): all scheduling is based on {@link Util#getMeasuringTimeMs()}
 *   and driven from Fabric's END_CLIENT_TICK event, so the render loop never blocks.
 * - One executor instance drives every macro; each macro owns a transient RuntimeState.
 * - stop() always releases every key the engine pressed, so a macro can never
 *   leave a key or mouse button stuck.
 */
public class MacroExecutor {
    /** How long a synthesized "tap" (click / key press) stays held. */
    private static final long TAP_MS = 25;

    private final MacroManager manager;

    public MacroExecutor(MacroManager manager) {
        this.manager = manager;
    }

    public boolean isRunning(Macro m) {
        return m.runtime.running;
    }

    public int runningCount() {
        int n = 0;
        for (Macro m : manager.macros()) {
            if (m.runtime.running) n++;
        }
        return n;
    }

    public void start(Macro m) {
        if (m.actions.isEmpty() || m.runtime.running) {
            return;
        }
        RuntimeState rt = m.runtime;
        rt.running = true;
        rt.index = 0;
        rt.nextActionAtMs = 0L;
        rt.heldKeys.clear();
        rt.releases.clear();
    }

    /** Stops the macro and releases every input it is responsible for. Safe to call anytime. */
    public void stop(Macro m) {
        RuntimeState rt = m.runtime;
        if (!rt.running && rt.heldKeys.isEmpty() && rt.releases.isEmpty()) {
            return;
        }
        rt.running = false;
        rt.index = 0;
        rt.nextActionAtMs = 0L;
        for (InputUtil.Key k : rt.heldKeys) {
            syntheticUp(k);
        }
        rt.heldKeys.clear();
        for (ScheduledRelease r : rt.releases) {
            syntheticUp(r.key);
        }
        rt.releases.clear();
    }

    public void stopAll() {
        for (Macro m : manager.macros()) {
            stop(m);
        }
    }

    /** Called once per client tick from MacroManager. */
    public void tick(MinecraftClient client) {
        long now = Util.getMeasuringTimeMs();
        for (Macro m : manager.macros()) {
            RuntimeState rt = m.runtime;
            if (!rt.running) {
                continue;
            }
            // Release finished holds / taps. Uses a monotonic ms clock, not tick counts,
            // so sub-tick delays (10 ms etc.) resolve at the closest tick without busy loops.
            if (!rt.releases.isEmpty()) {
                Iterator<ScheduledRelease> it = rt.releases.iterator();
                while (it.hasNext()) {
                    ScheduledRelease r = it.next();
                    if (now >= r.atMs) {
                        syntheticUp(r.key);
                        it.remove();
                    }
                }
            }
            if (now < rt.nextActionAtMs) {
                continue;
            }
            step(m, rt, now);
        }
    }

    /**
     * Runs actions from the cursor until an action consumes time (WAIT / KEY_HOLD)
     * or the list ends. Zero-delay chains (e.g. click + wait + click) collapse into
     * a single tick, which keeps timing as tight as the game loop allows.
     */
    private void step(Macro m, RuntimeState rt, long now) {
        List<MacroAction> actions = m.actions;
        while (rt.index < actions.size()) {
            MacroAction a = actions.get(rt.index++);
            switch (a.type) {
                case LEFT_CLICK:
                    tap(InputUtil.Type.MOUSE.createFromCode(GLFW.GLFW_MOUSE_BUTTON_LEFT), rt, now);
                    break;
                case RIGHT_CLICK:
                    tap(InputUtil.Type.MOUSE.createFromCode(GLFW.GLFW_MOUSE_BUTTON_RIGHT), rt, now);
                    break;
                case KEY_PRESS:
                    tap(a.toKey(), rt, now);
                    break;
                case KEY_HOLD: {
                    InputUtil.Key key = a.toKey();
                    long dur = Math.max(10, a.durationMs);
                    syntheticDown(key);
                    rt.heldKeys.add(key);
                    rt.releases.add(new ScheduledRelease(key, now + dur));
                    rt.nextActionAtMs = now + dur;
                    break;
                }
                case KEY_RELEASE: {
                    InputUtil.Key key = a.toKey();
                    syntheticUp(key);
                    rt.heldKeys.remove(key);
                    rt.releases.removeIf(r -> r.key.equals(key));
                    break;
                }
                case WAIT:
                    rt.nextActionAtMs = now + Math.max(0, a.delayMs);
                    break;
            }
            if (rt.nextActionAtMs > now) {
                break;
            }
        }
        if (rt.index >= actions.size()) {
            if (m.mode() == Macro.RepeatMode.ONCE) {
                stop(m);
            } else {
                rt.index = 0;
                rt.nextActionAtMs = now + Math.max(0, m.repeatDelayMs);
            }
        }
    }

    private void tap(InputUtil.Key key, RuntimeState rt, long now) {
        syntheticDown(key);
        rt.releases.add(new ScheduledRelease(key, now + TAP_MS));
    }

    /**
     * Synthesizes a key-down the same way GLFW input would: updates the bound
     * KeyBinding's pressed state and its press counter (so wasPressed() consumers fire).
     */
    private static void syntheticDown(InputUtil.Key key) {
        KeyBinding.setKeyPressed(key, true);
        KeyBinding.onKeyPressed(key);
    }

    private static void syntheticUp(InputUtil.Key key) {
        KeyBinding.setKeyPressed(key, false);
    }

    /** A key that must be released at a specific timestamp. */
    static final class ScheduledRelease {
        final InputUtil.Key key;
        final long atMs;

        ScheduledRelease(InputUtil.Key key, long atMs) {
            this.key = key;
            this.atMs = atMs;
        }
    }
}
