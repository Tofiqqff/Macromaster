package com.macromaster.macro;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Global emergency stop: instantly halts every running macro and releases
 * every synthesized input. Bound to a key (default F8) via MacroManager.
 */
public final class EmergencyStop {
    private EmergencyStop() {
    }

    public static void activate(MacroManager manager) {
        manager.executor().stopAll();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(
                    Text.literal("\u00A7e[MacroMaster] \u00A7fAll macros stopped (emergency stop)."), true);
        }
        com.macromaster.MacroMasterClient.LOGGER.info("Emergency stop activated: all macros halted.");
    }
}
