package com.macromaster.macro;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Owns all macros, their KeyBindings and the global keys (manager / emergency stop).
 * All key events are consumed every client tick from the main thread — nothing here
 * blocks, sleeps or spawns threads.
 */
public class MacroManager {
    private final List<Macro> macros = new ArrayList<>();
    private final Map<String, KeyBinding> triggerBindings = new LinkedHashMap<>();
    private final MacroExecutor executor = new MacroExecutor(this);
    private MacroSettings settings = new MacroSettings();
    private KeyBinding.Category category;
    private KeyBinding managerBinding;
    private KeyBinding emergencyBinding;

    public void init() {
        this.category = new KeyBinding.Category(Identifier.of(com.macromaster.MacroMasterClient.MOD_ID, "macros"));
        MacroConfig.load(this);
        if (macros.isEmpty()) {
            macros.add(createSampleMacro());
        }
        managerBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.macromaster.manager", settings.managerKey().getCode(), category));
        emergencyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.macromaster.emergency", settings.emergencyKey().getCode(), category));
        for (Macro m : macros) {
            registerTrigger(m);
        }
        MacroConfig.save(this);
    }

    private Macro createSampleMacro() {
        Macro m = new Macro();
        m.name = "Sample Combo";
        m.enabled = false;
        m.trigger = "key.keyboard:71"; // G
        m.actions.add(new MacroAction(MacroAction.Type.LEFT_CLICK));
        MacroAction w1 = new MacroAction(MacroAction.Type.WAIT); w1.delayMs = 100; m.actions.add(w1);
        m.actions.add(new MacroAction(MacroAction.Type.RIGHT_CLICK));
        MacroAction w2 = new MacroAction(MacroAction.Type.WAIT); w2.delayMs = 150; m.actions.add(w2);
        MacroAction sp = new MacroAction(MacroAction.Type.KEY_PRESS); sp.setKey(InputUtil.Type.KEYSYM.createFromCode(GLFW.GLFW_KEY_SPACE)); m.actions.add(sp);
        MacroAction w3 = new MacroAction(MacroAction.Type.WAIT); w3.delayMs = 50; m.actions.add(w3);
        m.actions.add(new MacroAction(MacroAction.Type.RIGHT_CLICK));
        return m;
    }

    // ---------- macro collection ----------

    public List<Macro> macros() {
        return macros;
    }

    public MacroExecutor executor() {
        return executor;
    }

    public MacroSettings settings() {
        return settings;
    }

    public void setSettings(MacroSettings s) {
        this.settings = s != null ? s : new MacroSettings();
    }

    public void addMacro(Macro m) {
        macros.add(m);
        registerTrigger(m);
        MacroConfig.save(this);
    }

    public void deleteMacro(Macro m) {
        executor.stop(m);
        macros.remove(m);
        KeyBinding b = triggerBindings.remove(m.id);
        if (b != null) {
            // Unbind so the dead binding can never fire again.
            b.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(GLFW.GLFW_KEY_UNKNOWN));
        }
        MacroConfig.save(this);
    }

    /** Persists current state (macro edits, order, settings). */
    public void persist() {
        MacroConfig.save(this);
    }

    // ---------- key handling ----------

    private void registerTrigger(Macro m) {
        KeyBinding existing = triggerBindings.get(m.id);
        InputUtil.Key key = MacroAction.keyFromString(m.trigger);
        if (existing == null) {
            existing = KeyBindingHelper.registerKeyBinding(
                    new KeyBinding("key.macromaster.trigger", key.getCode(), category));
            triggerBindings.put(m.id, existing);
        } else {
            existing.setBoundKey(key);
        }
    }

    public void updateTrigger(Macro m, InputUtil.Key key) {
        m.trigger = MacroAction.keyToString(key);
        registerTrigger(m);
        MacroConfig.save(this);
    }

    public void setManagerKey(InputUtil.Key key) {
        settings.setManagerKey(key);
        if (managerBinding != null) {
            managerBinding.setBoundKey(key);
        }
        MacroConfig.save(this);
    }

    public void setEmergencyKey(InputUtil.Key key) {
        settings.setEmergencyKey(key);
        if (emergencyBinding != null) {
            emergencyBinding.setBoundKey(key);
        }
        MacroConfig.save(this);
    }

    /**
     * Returns another macro that currently uses the same trigger key, or null.
     */
    public Macro findTriggerConflict(Macro self, InputUtil.Key key) {
        for (Macro m : macros) {
            if (m.id.equals(self.id)) {
                continue;
            }
            if (MacroAction.keyFromString(m.trigger).equals(key)) {
                return m;
            }
        }
        return null;
    }

    /** Main-thread per-tick logic: global keys, trigger handling, executor. */
    public void onTick(MinecraftClient client) {
        if (managerBinding != null) {
            while (managerBinding.wasPressed()) {
                client.setScreen(new com.macromaster.gui.MacroListScreen(client.currentScreen));
            }
        }
        if (emergencyBinding != null && emergencyBinding.wasPressed()) {
            EmergencyStop.activate(this);
        }

        boolean inGame = client.player != null && client.currentScreen == null;
        for (Macro m : macros) {
            KeyBinding b = triggerBindings.get(m.id);
            if (b == null) {
                continue;
            }
            // Always consume press events so the counter can never pile up.
            boolean pressedEvent = b.wasPressed();

            if (!inGame || !m.enabled) {
                if (executor.isRunning(m)) {
                    executor.stop(m);
                }
                continue;
            }

            switch (m.mode()) {
                case ONCE:
                    if (pressedEvent && !executor.isRunning(m)) {
                        executor.start(m);
                    }
                    break;
                case TOGGLE:
                    if (pressedEvent) {
                        if (executor.isRunning(m)) {
                            executor.stop(m);
                        } else {
                            executor.start(m);
                        }
                    }
                    break;
                case HOLD:
                    if (b.isPressed()) {
                        if (!executor.isRunning(m)) {
                            executor.start(m);
                        }
                    } else if (executor.isRunning(m)) {
                        executor.stop(m);
                    }
                    break;
            }
        }

        executor.tick(client);
    }

    /** Final cleanup: stop everything and persist. */
    public void shutdown() {
        executor.stopAll();
        MacroConfig.save(this);
    }
}
