package com.macromaster.macro;

import net.minecraft.client.util.InputUtil;

/** Global mod settings, persisted inside macromaster.json. */
public class MacroSettings {
    public String managerKey = "key.keyboard:96";    // default: GRAVE ACCENT (`)
    public String emergencyKey = "key.keyboard:290"; // default: F8
    public boolean hudEnabled = true;

    public InputUtil.Key managerKey() {
        return MacroAction.keyFromString(managerKey);
    }

    public InputUtil.Key emergencyKey() {
        return MacroAction.keyFromString(emergencyKey);
    }

    public void setManagerKey(InputUtil.Key k) {
        this.managerKey = MacroAction.keyToString(k);
    }

    public void setEmergencyKey(InputUtil.Key k) {
        this.emergencyKey = MacroAction.keyToString(k);
    }
}
