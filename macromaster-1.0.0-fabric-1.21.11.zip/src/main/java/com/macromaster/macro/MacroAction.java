package com.macromaster.macro;

import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * A single, serializable step of a macro.
 * Key-based actions store their key as "key.keyboard:32" / "key.mouse:0" style strings
 * so the configuration stays plain JSON.
 */
public class MacroAction {
    public enum Type {
        LEFT_CLICK, RIGHT_CLICK, KEY_PRESS, KEY_HOLD, KEY_RELEASE, WAIT;

        public String label() {
            switch (this) {
                case LEFT_CLICK: return "Left Click";
                case RIGHT_CLICK: return "Right Click";
                case KEY_PRESS: return "Key Press";
                case KEY_HOLD: return "Key Hold";
                case KEY_RELEASE: return "Key Release";
                case WAIT: return "Wait / Delay";
                default: return name();
            }
        }

        public String description() {
            switch (this) {
                case LEFT_CLICK: return "Performs a single left mouse button click.";
                case RIGHT_CLICK: return "Performs a single right mouse button click.";
                case KEY_PRESS: return "Presses and releases a keyboard or mouse key once.";
                case KEY_HOLD: return "Holds a key down for a configurable duration.";
                case KEY_RELEASE: return "Releases a key that is currently held down.";
                case WAIT: return "Waits for a configurable delay before the next action.";
                default: return "";
            }
        }
    }

    public Type type = Type.WAIT;

    /** Serialized key: "key.keyboard:32" (KEYSYM) or "key.mouse:0" (MOUSE). */
    public String key = "key.keyboard:32"; // default: SPACE

    /** KEY_HOLD duration in milliseconds. */
    public int durationMs = 500;

    /** WAIT delay in milliseconds. */
    public int delayMs = 100;

    public MacroAction() {
    }

    public MacroAction(Type type) {
        this.type = type;
        if (type == Type.KEY_HOLD) {
            this.durationMs = 500;
        } else if (type == Type.WAIT) {
            this.delayMs = 100;
        }
    }

    public static String keyToString(InputUtil.Key k) {
        return k.getCategory().getName() + ":" + k.getCode();
    }

    public static InputUtil.Key keyFromString(String s) {
        try {
            int i = s.indexOf(':');
            InputUtil.Type t = InputUtil.Type.byName(s.substring(0, i));
            return t.createFromCode(Integer.parseInt(s.substring(i + 1)));
        } catch (Exception e) {
            return InputUtil.Type.KEYSYM.createFromCode(GLFW.GLFW_KEY_SPACE);
        }
    }

    public InputUtil.Key toKey() {
        return keyFromString(key);
    }

    public void setKey(InputUtil.Key k) {
        this.key = keyToString(k);
    }

    public String keyName() {
        return toKey().getLocalizedText().getString();
    }

    public String summary() {
        switch (type) {
            case LEFT_CLICK: return "Left Click";
            case RIGHT_CLICK: return "Right Click";
            case KEY_PRESS: return "Key Press: " + keyName();
            case KEY_HOLD: return "Key Hold: " + keyName() + " (" + durationMs + " ms)";
            case KEY_RELEASE: return "Key Release: " + keyName();
            case WAIT: return "Wait " + delayMs + " ms";
            default: return "?";
        }
    }

    public MacroAction copy() {
        MacroAction c = new MacroAction();
        c.type = this.type;
        c.key = this.key;
        c.durationMs = this.durationMs;
        c.delayMs = this.delayMs;
        return c;
    }
}
