package com.macromaster.macro;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * A macro: an ordered list of actions executed from a single trigger key.
 * All fields are Gson-serializable plain data; runtime state is transient.
 */
public class Macro {
    public enum RepeatMode {
        ONCE("Run Once"), TOGGLE("Toggle Repeat"), HOLD("Hold to Repeat");

        public final String label;

        RepeatMode(String label) {
            this.label = label;
        }

        public RepeatMode next() {
            RepeatMode[] v = values();
            return v[(ordinal() + 1) % v.length];
        }
    }

    public String id = UUID.randomUUID().toString();
    public String name = "New Macro";
    public boolean enabled = true;
    public String repeatMode = "ONCE";
    public int repeatDelayMs = 0;
    public String trigger = "key.keyboard:71"; // default: G

    public List<MacroAction> actions = new ArrayList<>();

    /** Live execution state — never serialized. */
    public transient RuntimeState runtime = new RuntimeState();

    public RepeatMode mode() {
        try {
            return RepeatMode.valueOf(repeatMode);
        } catch (Exception e) {
            return RepeatMode.ONCE;
        }
    }

    public Macro copy() {
        Macro c = new Macro();
        c.id = this.id;
        c.name = this.name;
        c.enabled = this.enabled;
        c.repeatMode = this.repeatMode;
        c.repeatDelayMs = this.repeatDelayMs;
        c.trigger = this.trigger;
        for (MacroAction a : this.actions) {
            c.actions.add(a.copy());
        }
        return c;
    }

    /** Live per-macro execution state, driven by the tick-based MacroExecutor. */
    public static class RuntimeState {
        public boolean running = false;
        public int index = 0;
        public long nextActionAtMs = 0L;
        public final java.util.Set<net.minecraft.client.util.InputUtil.Key> heldKeys = new java.util.HashSet<>();
        public final java.util.List<MacroExecutor.ScheduledRelease> releases = new java.util.ArrayList<>();
    }
}
