# MacroMaster 1.0.0

A polished client-side macro mod for **Minecraft Java 1.21.11 (Fabric)**.
One key press -> a reliable, ordered chain of clicks, key presses, holds and precise delays.

## Features
- Macro Manager GUI (dark, professional design) - open with the manager key (default: ` `)
- Ordered action chains: Left/Right Click, Key Press, Key Hold, Key Release, Wait/Delay
- Per-action editing: add, edit, delete, move up/down, duplicate
- Repeat modes: Run Once / Toggle Repeat / Hold to Repeat (+ configurable repeat delay)
- Emergency stop key (default: F8) - halts everything and releases all inputs instantly
- Duplicate-trigger conflict warnings
- JSON config (`config/macromaster.json`) with corrupt-file auto-backup
- Optional HUD indicator (top-right, non-intrusive)
- Mod Menu integration (soft dependency, optional)

## Build
```
gradle wrapper --gradle-version 8.14.3   # only the first time, if gradlew jar is missing
./gradlew build
```
Output JAR: `build/libs/macromaster-1.0.0.jar`

## Install
1. Install Fabric Loader 0.18.1+ for Minecraft 1.21.11
2. Put `fabric-api-0.139.4+1.21.11.jar` and `macromaster-1.0.0.jar` into `.minecraft/mods/`
3. Launch the game

## How to use
1. In-game press the manager key (default `` ` ``) to open the Macro Manager
2. Press **+ Create Macro** - set a name, click **Trigger** and press any key/mouse button
3. Press **+ Add Action** to build the chain, e.g.:
   Left Click -> Wait 100 ms -> Right Click -> Wait 150 ms -> Key Press: Space
4. Use the arrows to reorder, the copy icon to duplicate, the pencil to edit
5. Press **Save**, then press your trigger key in-game

Repeat modes:
- **Run Once** - executes one time per press
- **Toggle Repeat** - press to start looping, press again to stop
- **Hold to Repeat** - loops while the trigger is held

## Safety
- No threads, no Thread.sleep - tick-driven scheduler with a monotonic ms clock
- Every stop path (screen open, disconnect, shutdown, emergency stop) releases held keys
- Sub-tick waits resolve on the next client tick (game loop limits real minimum to ~50 ms)

## License
MIT
